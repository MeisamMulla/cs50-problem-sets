SELECT
	movies.title
FROM
	movies
	JOIN people ON people.id = stars.person_id
	JOIN stars ON stars.person_id = people.id
	JOIN ratings ON ratings.movie_id = movies.id
WHERE
	people.name = "Chadwick Boseman"
GROUP BY
	movies.title
ORDER BY
	ratings.rating DESC
LIMIT 5